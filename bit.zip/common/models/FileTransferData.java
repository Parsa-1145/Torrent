package common.models;

public record FileTransferData(String file, String otherAddress) {
}
